# data/

Bu klasörde proje için kullanılan ham veriler yer alır. Büyük dosyalar GitHub'a push edilmez.
- **thyao.csv, vb.** gibi dosyalarınızı buraya koyun.
- Verileri paylaşmanız lisans açısından sakıncalıysa (ör. borsa verileri), **kaynağı ve indirme yöntemini README'de anlatın**, dosyayı burada tutmayın.