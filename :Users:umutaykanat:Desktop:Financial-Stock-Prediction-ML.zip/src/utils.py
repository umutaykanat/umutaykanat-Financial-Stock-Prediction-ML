import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def make_supervised(series: pd.Series, lookback: int = 30):
    """Turn a univariate series into supervised learning dataset."""
    X, y = [], []
    values = series.values.astype(float)
    for i in range(lookback, len(values)):
        X.append(values[i-lookback:i])
        y.append(values[i])
    return np.array(X), np.array(y)

def scale_series(series: pd.Series):
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(series.values.reshape(-1,1)).flatten()
    return pd.Series(scaled, index=series.index), scaler